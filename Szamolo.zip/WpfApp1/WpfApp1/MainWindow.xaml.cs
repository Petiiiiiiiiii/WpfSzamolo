﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string operand1 = "";
        private List<double> numbers = new List<double>();
        private string operation = "";

        public MainWindow()
        {
            InitializeComponent();
            gyokvonas.Visibility = Visibility.Collapsed;
            hatvany.Visibility = Visibility.Collapsed;
        }

        private void szam_Click(object sender, RoutedEventArgs e)
        {
            if (egeszSzamolas.Content.ToString().Trim() == "")
            {
                Button button = (Button)sender;
                string content = button.Content.ToString();
                operand1 += content;
                egeszSzamolas.Content = operand1;
            }
            else 
            {
                if (egeszSzamolas.Content.ToString()[0] == '√')
                {
                    Button button = (Button)sender;
                    string content = button.Content.ToString();
                    operand1 += content;
                    egeszSzamolas.Content = "√" + operand1;
                }
                else 
                {
                    Button button = (Button)sender;
                    string content = button.Content.ToString();
                    operand1 += content;
                    egeszSzamolas.Content = operand1;
                }
            }

        }

        private void Operator_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            operation = button.Content.ToString();
            numbers.Add(double.Parse(operand1));
            operand1 = "";
            egeszSzamolas.Content += " " + operation;
        }

        private void TobbiGombShow(object sender, RoutedEventArgs e)
        {
            if (tudomanyosBool.IsChecked == true)
            {
                gyokvonas.Visibility = Visibility.Visible;
                hatvany.Visibility = Visibility.Visible;
            }
            else 
            {
                gyokvonas.Visibility= Visibility.Collapsed;
                hatvany.Visibility= Visibility.Collapsed;
            }
        }

        private void Egyenlo_Click(object sender, RoutedEventArgs e)
        {
            if (operand1 != "")
            {
                numbers.Add(double.Parse(operand1));
                operand1 = "";
            }

            double result = numbers[0];

            for (int i = 0; i < numbers.Count - 1; i++)
            {
                switch (operation)
                {
                    case "+":
                        result += numbers[i + 1];
                        break;
                    case "-":
                        result -= numbers[i + 1];
                        break;
                    case "*":
                        result *= numbers[i + 1];
                        break;
                    case "/":
                        if (numbers[i + 1] != 0)
                            result /= numbers[i + 1];
                        else
                        {
                            MessageBox.Show("Nem oszthatunk nullával!");
                            return;
                        }
                        break;
                    case "^":
                        result = Math.Pow(numbers[0], numbers[i + 1]);
                        break;
                    case "√":
                        result = Math.Sqrt(numbers[0]);
                        break;
                }
            }

            eredmeny.Content = result.ToString();
            numbers.Clear();
            operation = "";
            egeszSzamolas.Content = "";
        }

        private void Torles_Click(object sender, RoutedEventArgs e)
        {
            operand1 = "";
            numbers.Clear();
            operation = "";
            eredmeny.Content = "";
            egeszSzamolas.Content = "";
        }

        private void GyokvonasClick(object sender, RoutedEventArgs e)
        {
            egeszSzamolas.Content = "√";
            operation = "√";
        }
    }
}